#include <stdio.h>
#include <stdlib.h>

void adios(){

	printf("\nGracias por usar este programa.\nHasta la proxima.\n\n");
	printf("\x1B[34m 					=========================\n					*                       *\n					*          iiii         *\n					*         |~~~~|        *\n					*        |~~~~~~|       *\n					*       |uuuuuuuu|      *\n					*      |nnnnnnnnnn|     *\n					*                       *");
	printf("\n					*  A 4years Production  *\n					*      Pie Software!    *\n					*                       *\n					* Pablo Jiménez Rebollo *\n					*                       *\n					=========================\n\n");

	printf("\x1B[0m");

	printf("El programa se cerrará automáticamente en:");
	printf("   10 segundos...\n\n");

	system("sleep 1");
	printf("Cerrando el programa ...\n");
	system("sleep 2");
	printf("Buscando el monte del destino ...\n");
	system("sleep 2");
	printf("Apalizando a los orcos ...\n");
	system("sleep 2");
	printf("Pagando a los gnomos ...\n");
	system("sleep 2");
	printf("Descanso para un pan de lembas y un vinito ... \n");
	system("sleep 2");
	printf("Defendiendo el abismo de Helm ...\n");
	system("sleep 2");
	printf("Echando la bronca a Gandalf por llegar siempre tarde ...\n");
	system("sleep 2");
	printf("Defendiendo Gondor, que esta Sauron un poco pesao ya ...\n");
	system("sleep 2");
	printf("Colandonos en mordor ...\n");
	system("sleep 2");
	printf("Resolviendo las diferencias con Golum a ver si tiramos ya el anillete...\n");
	system("sleep 2");
	printf("Anillo destruido, menos mal.\n");
	system("sleep 2");

	system("clear");

}
