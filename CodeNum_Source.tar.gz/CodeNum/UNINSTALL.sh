rm ~/.local/share/applications/CodeNum.desktop
rm -R ~/.CodeNum/
sudo rm /usr/bin/CodeNum
rm ~/Escritorio/CodeNum.desktop
sudo rm /usr/share/applications/CodeNum.desktop
sudo rm /usr/bin/UNINSTALL_CodeNum.sh
rm ~/Escritorio/CodeNum_Uninstall.desktop
sudo rm /usr/share/applications/CodeNum_Uninstall.desktop
sudo rm /usr/share/pixmaps/CodeNum.png
